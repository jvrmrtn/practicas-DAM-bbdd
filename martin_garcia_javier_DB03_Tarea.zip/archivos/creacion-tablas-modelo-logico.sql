CREATE TABLE TUTORES(
    dni                     VARCHAR(9)      CONSTRAINT tut_dni_PK PRIMARY KEY,
    nombre                  VARCHAR(15)     NOT NULL,
    apellido1               VARCHAR(20)     NOT NULL,
    apellido2               VARCHAR(20)     NOT NULL,
    email                   VARCHAR(40)     NOT NULL UNIQUE,
    telefono                VARCHAR(9)      NOT NULL UNIQUE
);

CREATE TABLE PROYECTOS(
    codProyecto             VARCHAR(7)      CONSTRAINT pro_codp_PK PRIMARY KEY,
    titulo                  VARCHAR(30)     NOT NULL,
    descripcion             VARCHAR(50)     NOT NULL,
    tutor                   VARCHAR(9)      CONSTRAINT pro_tut_FK REFERENCES TUTORES(dni) NOT NULL,
    fecPresentacion         DATE            NOT NULL,
    nota                    DECIMAL(4,2)    NOT NULL
);

CREATE TABLE ALUMNOS(
    dni                     VARCHAR(9)      CONSTRAINT alu_dni_PK PRIMARY KEY,
    nombre                  VARCHAR(15)     NOT NULL,
    apellido1               VARCHAR(20)     NOT NULL,
    apellido2               VARCHAR(20)     NOT NULL,
    fecNacimiento           DATE            NOT NULL,
    direccion               VARCHAR(30)     NOT NULL,
    municipio               VARCHAR(20)     NOT NULL,
    provincia               VARCHAR(20)     NOT NULL,
    codPostal               VARCHAR(5)      NOT NULL,   
    email                   VARCHAR(40)     NOT NULL UNIQUE,
    telefono                VARCHAR(9)      NOT NULL UNIQUE,
    codProyecto             VARCHAR(7)      CONSTRAINT alu_codp_FK REFERENCES PROYECTOS(codProyecto) NOT NULL
);

CREATE TABLE TITULOS(
    codTitulo               VARCHAR(8)      CONSTRAINT tit_codt_PK PRIMARY KEY,
    titulo                  VARCHAR(30)     NOT NULL,
    ano                     VARCHAR(4)      NOT NULL,
    nota                    NUMBER(2)       CHECK (nota BETWEEN 1 AND 10)
);

CREATE TABLE CENTROS(
    codCentro               VARCHAR(8)      CONSTRAINT cen_codc_PK PRIMARY KEY,
    nombre                  VARCHAR(30)     NOT NULL,
    municipio               VARCHAR(20)     NOT NULL,
    provincia               VARCHAR(20)     NOT NULL
);

--AL EXISTIR UNA RELACION TERNARIA [N:M:P] ENTRE ALUMNO,TITULO Y CENTRO
--CONVIERTO ESTA RELACION EN UNA TABLA FORMADA POR CADA UNA DE LAS PK
--DE LAS TABLAS QUE INTERVIENEN EN ESTA RELACION COMO FK
--ADEMAS, CREO UNA PK QUE LA IDENTIFIQUE PARA NORMALIZARLA.
CREATE TABLE ESTUDIOS(
    codEstudio              VARCHAR(7)      CONSTRAINT est_code_PK PRIMARY KEY,
    dniAlumno               VARCHAR(9)      CONSTRAINT est_dni_FK REFERENCES ALUMNOS(dni) NOT NULL,
    codTitulo               VARCHAR(8)      CONSTRAINT est_codt_FK REFERENCES TITULOS(codTitulo) NOT NULL,
    codCentro               VARCHAR(8)      CONSTRAINT est_codc_FK REFERENCES CENTROS(codCentro) NOT NULL
);

CREATE TABLE ACTIVIDADES(
    codActividad            VARCHAR(3)      CONSTRAINT act_coda_PK PRIMARY KEY,
    descripcion             VARCHAR(50)     NOT NULL
);

CREATE TABLE EMPRESAS(
    cif                     VARCHAR(9)      CONSTRAINT emp_cif_PK PRIMARY KEY,
    nombre                  VARCHAR(30)     NOT NULL,
    numConvenio             VARCHAR(5)      NULL,
    direccion               VARCHAR(30)     NOT NULL,
    municipio               VARCHAR(20)     NOT NULL,
    codPostal               VARCHAR(5)      NOT NULL,
    email                   VARCHAR(40)     NOT NULL UNIQUE,
    telefono                VARCHAR(9)      NOT NULL UNIQUE,
    pagWeb                  VARCHAR(28)     NOT NULL UNIQUE
);

--AL HABER UNA RELACION [N:M] ENTRE ACTIVIDADES Y EMPRESAS
--SE CREA UNA NUEVA TABLA QUE TENDRA SUS PK Y UNA PROPIA PARA IDENTIFICARLA.
CREATE TABLE ACTIVIDADES_EMPRESA(
    codActividadesEmpresa   VARCHAR(3)      CONSTRAINT acte_coda_PK PRIMARY KEY,
    cifEmpresa              VARCHAR(9)      CONSTRAINT acte_cife_FK REFERENCES EMPRESAS(cif) NOT NULL,
    codActividad            VARCHAR(3)      CONSTRAINT acte_coda_FK REFERENCES ACTIVIDADES(codActividad) NOT NULL
);

--HAY OTRA RELACION TERNARIA [N:M:P] ENTRE ALUMNO,EMPRESA Y ACTICVIDAD
--RESOLVEMOS IGUAL QUE EL CASO ANTERIOR, CREANDO UNA NUEVA TABLA DE LA RELACION "TRABAJA"
--CON LAS PK COMO FK Y UNA CREO UNA NUEVA PK QUE LA IDENTIFIQUE.
--ADEMAS DE A�ADIR LOS ATRIBUTOS DE LA RELACION A ESTA TABLA NUEVA
CREATE TABLE TRABAJOS(
    codTrabajo              VARCHAR(5)      CONSTRAINT tra_codt_PK PRIMARY KEY,
    fecInicio               DATE            NOT NULL,
    fecFin                  DATE            NULL,
    codActividad            VARCHAR(3)      CONSTRAINT tra_coda_FK REFERENCES ACTIVIDADES(codActividad) NOT NULL,
    cifEmpresa              VARCHAR(9)      CONSTRAINT tra_cife_FK REFERENCES EMPRESAS(cif) NOT NULL,
    dniAlumno               VARCHAR(9)      CONSTRAINT tra_dnia_FK REFERENCES ALUMNOS(dni) NOT NULL
);

--TENGO OTRA RELACION TERNARIA ENTRE ALUMNO,EMPRESA Y ACTIVIDAD
--EN ESTE CASO [1:N:M], QUE EN ESTE CASO RESUELVO IGUAL YA QUE,
--AL CREAR UN CAMPO PARA A�ADIRLE UNA PK
--YA NINGUN CONJUNTO DE FK FUNCIONAN COMO PK DENTRO DE ESTA TABLA.
CREATE TABLE FCTS(
    codFct                  VARCHAR(8)      CONSTRAINT fct_codf_PK PRIMARY KEY,
    convocatoria            VARCHAR(3)      CHECK(convocatoria = 'JUN' OR convocatoria = 'DIC') NOT NULL,
    ano                     VARCHAR(4)      NOT NULL,
    codActividad            VARCHAR(3)      CONSTRAINT fct_coda_FK REFERENCES ACTIVIDADES(codActividad) NOT NULL,
    cifEmpresa              VARCHAR(9)      CONSTRAINT fct_cife_FK REFERENCES EMPRESAS(cif) NOT NULL,
    dniAlumno               VARCHAR(9)      CONSTRAINT fct_dnia_FK REFERENCES ALUMNOS(dni) NOT NULL
);