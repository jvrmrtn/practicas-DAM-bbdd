CREATE TABLE FAMILIA(
    --Codigo que distingue a una familia de otra, numero de 3 digitos, clave primaria.
    Codfamilia NUMBER(3) CONSTRAINT fam_codf_PK PRIMARY KEY,
    --Denominacion de la familia, alfanumerico de 50 caracteres, no puede haber 2 familias con la misma denominacion, debe tener contenido.
    Denofamilia VARCHAR2(50) UNIQUE NOT NULL
);

CREATE TABLE PRODUCTO(
    --Codigo que distingue un producto de otro, numero de 5 digitos, clave primaria.
    Codproducto NUMBER(5) CONSTRAINT pro_codf_PK PRIMARY KEY,
    --Denominacion del producto, alfanumerico de 20 caracteres, debe tener contenido.
    Denoproducto VARCHAR2(20) NOT NULL,
    --Descripcion del producto, alfanumerico de 100 caracteres.
    Descripcion VARCHAR2(100),
    --Precio base del producto, numerico de 8 digitos, 2 de ellos decimales, mayor que 0, debe tener contenido.
    PrecioBase DECIMAL(8,2) CHECK (PrecioBase > 0) NOT NULL,
    --Porcentaje de reposicion aplicado a ese producto, numerico de 3 digitos, mayor que 0.
    PorcReposicion NUMBER(3) CHECK (PorcReposicion > 0),
    --Unidades minimas recomendables en almacen, numerico de 4 digitos, mayor que 0, debe tener contenido.
    UnidadesMinimas NUMBER(4) CHECK (UnidadesMinimas > 0) NOT NULL,
    --Codigo de la familia a la que pertenece el producto, numerico de 3 digitos, clave ajena, referencia a Codfamilia de tabla FAMILIA, debe tener contenido.
    Codfamilia NUMBER(3) CONSTRAINT pro_codf_FK REFERENCES FAMILIA(Codfamilia) NOT NULL
);

CREATE TABLE TIENDA (
    --Codigo que distingue una tienda a otra, numero de 3 digitos, clave primaria.
    Codtienda NUMBER(3) CONSTRAINT tie_codt_PK PRIMARY KEY,
    --Denominacion de tienda, alfanumerico de 20 caracteres, debe tener contenido.
    Denotienda VARCHAR2(20) NOT NULL,
    --Telefono de la tienda, alfanumerico de 11 caracteres.
    Telefono VARCHAR2(11),
    --Codigo postal, alfanumerico de 5 caracteres, debe tener contenido.
    CodigoPostal VARCHAR2(5) NOT NULL,
    --Provincia donde se ubica la tienda, alfanumerico de 5 caracteres, debe tener contenido.
    Provincia VARCHAR2(5) NOT NULL
);

CREATE TABLE STOCK (
    --Codigo de tienda, numerico de 3 digitos, clave ajena, referencia a Codtienda de la tabla TIENDA, debe tener contenido.
    Codtienda NUMBER(3) CONSTRAINT sto_codt_FK REFERENCES TIENDA(Codtienda) NOT NULL,
    --Codigo del procuto, numerico de 5 digitos, clave ajena, referencia a Codproducto de la tabla PRODUCTO, debe tener contenido
    Codproducto NUMBER(5) CONSTRAINT sto_codp_FK REFERENCES PRODUCTO(Codproducto) NOT NULL,
    --Unidades de ese producto en tienda, numerico de 6 digitos, mayor o igual a 0, debe tener contenido
    Unidades NUMBER(6) CHECK (Unidades >= 0) NOT NULL,
    --Clave primaria(Codtienda, Codproducto) Permite que un producto pueda aparecer en varias tiendas, y que en una tienda pueda haber varios productos.
    CONSTRAINT sto_PK PRIMARY KEY (Codtienda, Codproducto)
);